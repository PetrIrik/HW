#ifndef Card_h
#define Card_h
#include<string>
enum suit : int 
{
	CLUBS,
	DIAMONDS,
	HEARTS,
	SPADES
};

enum value  
{
	ACE = 1,
	TWO = 2,
	THREE ,
	FOUR ,
	FIVE ,
	SIX ,
	SEVEN ,
	EIGHTH ,
	NINE ,
	TEN  ,
	JACK ,
	QUEEN ,
	KING ,
};

class Card
{
public:
	Card() = delete;
	Card(const value eValue, const suit sSuit, const bool bShow = false);

	const value GetValue() const;
	const suit GetSuit() const;

	static std::string SuitToString(const suit eSuit);
	static std::string ValueToString(const value eValue);
	static int ValueToScore(const value eValue);

	const std::string toString() const;

	void Filp();

protected:
	suit m_Suit;
	value m_Value;
	bool m_bShow;
};

#endif // !Card_h

